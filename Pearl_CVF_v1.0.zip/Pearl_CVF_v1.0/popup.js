console.log("插件脚本已加载");

document.getElementById('scanBtn').addEventListener('click', async () => {
    const status = document.getElementById('status');
    const listContainer = document.getElementById('resultList');
    const downloadBtn = document.getElementById('downloadBtn');
    const keywordInput = document.getElementById('keyword').value.trim().toLowerCase();

    // 获取统计显示的 DOM 元素
    const scanCountEl = document.getElementById('scanCount');
    const foundCountEl = document.getElementById('foundCount');

    // 1. 获取用户选择的逻辑 (OR 还是 AND)
    const logicType = document.querySelector('input[name="searchLogic"]:checked').value;

    status.innerText = "⏳ 正在扫描页面...";
    status.style.color = "blue";
    listContainer.innerHTML = "";
    downloadBtn.style.display = 'none';

    // 重置统计数据
    if (scanCountEl) scanCountEl.innerText = "0";
    if (foundCountEl) foundCountEl.innerText = "0";

    try {
        const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

        if (!tab) {
            status.innerText = "❌ 无法获取页面。";
            return;
        }

        chrome.scripting.executeScript({
            target: { tabId: tab.id },
            func: (kws, logic) => {
                // --- 注入页面的逻辑开始 ---
                const results = [];
                const keywords = kws ? kws.split(/[，,]/).map(k => k.trim()).filter(k => k) : [];

                // CVPR/CVF 结构选择器
                const titles = document.querySelectorAll('dt.ptitle');

                // 【修改点1】这里直接获取扫描总数
                const totalScanned = titles.length;

                titles.forEach(dt => {
                    const titleText = dt.innerText.replace(/[\n\r]+/g, ' ').trim();
                    const lowerTitle = titleText.toLowerCase();

                    let isMatch = false;

                    if (keywords.length === 0) {
                        // 如果没输关键词，默认匹配所有
                        isMatch = true;
                    } else {
                        if (logic === 'and') {
                            // AND模式：必须包含每一个关键词
                            isMatch = keywords.every(kw => lowerTitle.includes(kw));
                        } else {
                            // OR模式：只要包含任意一个关键词
                            isMatch = keywords.some(kw => lowerTitle.includes(kw));
                        }
                    }

                    if (isMatch) {
                        // 匹配成功，寻找对应的 PDF 链接 (向下找兄弟节点)
                        let next = dt.nextElementSibling;
                        if (next && next.tagName === 'DD') {
                            let pdfLink = next.querySelector('a[href*="pdf"]');

                            // 如果第一个 DD 没找到，尝试下一个 DD (有时候中间有 form 表单)
                            if (!pdfLink) {
                                next = next.nextElementSibling;
                                if (next && next.tagName === 'DD') {
                                    pdfLink = next.querySelector('a[href*="pdf"], a');
                                    if (pdfLink && pdfLink.innerText.toLowerCase() !== 'pdf') pdfLink = null;
                                }
                            }

                            if (pdfLink && pdfLink.href) {
                                results.push({ title: titleText, url: pdfLink.href });
                            }
                        }
                    }
                });

                // 【修改点2】返回一个对象，包含 结果数组 和 扫描总数
                return { items: results, total: totalScanned };
                // --- 注入页面的逻辑结束 ---
            },
            // 把关键词和逻辑类型传进去
            args: [keywordInput, logicType]
        }, (response) => {
            // 错误处理
            if (chrome.runtime.lastError) {
                status.innerText = "❌ 错误: " + chrome.runtime.lastError.message;
                return;
            }
            if (!response || !response[0] || !response[0].result) {
                status.innerText = "❌ 读取失败。";
                return;
            }

            // 【修改点3】解构返回的数据
            const data = response[0].result;
            const foundItems = data.items; // 匹配到的论文数组
            const totalCount = data.total; // 扫描的总数

            // 【修改点4】更新界面的统计数字
            if (scanCountEl) scanCountEl.innerText = totalCount;
            if (foundCountEl) foundCountEl.innerText = foundItems.length;

            if (foundItems.length === 0) {
                status.innerText = logicType === 'and'
                    ? "⚠️ 未找到同时包含这些词的论文。"
                    : "⚠️ 未找到相关论文。";
                status.style.color = "#e67e22";
                return;
            }

            // 渲染列表
            status.innerText = `✅ 列表生成完成 (${logicType.toUpperCase()}模式)：`;
            status.style.color = "green";
            downloadBtn.style.display = 'block';

            foundItems.forEach((item, index) => {
                const div = document.createElement('div');
                div.className = 'item';
                div.innerHTML = `
          <input type="checkbox" checked data-url="${item.url}" data-title="${item.title}">
          <div class="item-content">
            <div class="item-title">${item.title}</div>
            <div class="item-url">${item.url}</div>
          </div>
        `;
                listContainer.appendChild(div);
            });

            // 下载点击事件
            downloadBtn.onclick = () => {
                const checkboxes = document.querySelectorAll('#resultList input:checked');
                const folder = document.getElementById('folder').value.trim() || "Papers";

                status.innerText = `🚀 下载 ${checkboxes.length} 个文件...`;

                checkboxes.forEach((chk, i) => {
                    setTimeout(() => {
                        const url = chk.getAttribute('data-url');
                        const title = chk.getAttribute('data-title');
                        const safeTitle = title.replace(/[\\/:*?"<>|]/g, '_').substring(0, 150);

                        chrome.downloads.download({ url: url, filename: `${folder}/${safeTitle}.pdf` });
                    }, i * 500);
                });
            };
        });

    } catch (err) {
        status.innerText = "❌ 异常: " + err.message;
    }
});